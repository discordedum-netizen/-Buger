import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AppProvider } from './context';
import { Navbar } from './components/Navbar';
import { Home } from './pages/Home';
import { Menu } from './pages/Menu';
import { Login, Signup } from './pages/Auth';
import { Cart, Checkout } from './pages/Checkout';
import { Dashboard } from './pages/Dashboard';

function App() {
  return (
    <AppProvider>
      <Router>
        <div className="min-h-screen bg-[#fafafa] flex flex-col">
          <Navbar />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/menu" element={<Menu />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/dashboard" element={<Dashboard />} />
            </Routes>
          </main>
          
          <footer className="bg-gray-900 text-white py-12">
            <div className="container mx-auto px-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
                <div className="col-span-1 md:col-span-2">
                  <h2 className="text-3xl font-bold italic mb-6 flex items-center gap-2">
                    <span className="bg-orange-600 text-white rounded-full w-10 h-10 flex items-center justify-center not-italic">$</span>
                    Burger
                  </h2>
                  <p className="text-gray-400 max-w-sm mb-8">
                    The ultimate destination for burger lovers. We serve the most delicious, 
                    juicy, and flavorful burgers in town. Quality you can taste in every bite.
                  </p>
                  <div className="flex gap-4">
                    {/* Social icons could go here */}
                  </div>
                </div>
                <div>
                  <h4 className="font-bold mb-6 text-lg uppercase tracking-wider">Quick Links</h4>
                  <ul className="space-y-4 text-gray-400">
                    <li><a href="/menu" className="hover:text-orange-500 transition">Menu</a></li>
                    <li><a href="/" className="hover:text-orange-500 transition">Our Story</a></li>
                    <li><a href="/" className="hover:text-orange-500 transition">Careers</a></li>
                    <li><a href="/" className="hover:text-orange-500 transition">Contact Us</a></li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold mb-6 text-lg uppercase tracking-wider">Payment Methods</h4>
                  <div className="flex flex-wrap gap-4 grayscale opacity-60">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/d/df/Jazz_Cash_Logo.png" alt="JazzCash" className="h-8" />
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6A5nSNoW2w7N3S7_N7k0y9H5k_n1_2_N_Gg&s" alt="EasyPaisa" className="h-8 rounded" />
                  </div>
                </div>
              </div>
              <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-500 text-sm">
                © {new Date().getFullYear()} $ Burger. All rights reserved.
              </div>
            </div>
          </footer>
        </div>
      </Router>
    </AppProvider>
  );
}

export default App;
