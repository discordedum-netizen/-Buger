import { Product } from './types';

export const products: Product[] = [
  {
    id: 'b1',
    name: 'The Big $ Burger',
    description: 'Triple patty with double cheese and secret sauce',
    price: 899,
    category: 'burger',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'b2',
    name: 'Zinger Burger',
    description: 'Crispy fried chicken fillet with lettuce and mayo',
    price: 499,
    category: 'burger',
    image: 'https://images.unsplash.com/photo-1513185158878-8d8c1827003f?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'b3',
    name: 'Classic Cheeseburger',
    description: 'Juicy beef patty with cheddar cheese',
    price: 399,
    category: 'burger',
    image: 'https://images.unsplash.com/photo-1571091718767-18b5b1457add?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'p1',
    name: 'Chicken Tikka Pizza',
    description: 'Spicy chicken tikka, onions, and green peppers',
    price: 799,
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    sizes: [
      { label: 'Small', price: 799 },
      { label: 'Medium', price: 1199 },
      { label: 'Large', price: 1499 }
    ]
  },
  {
    id: 'p2',
    name: 'Fajita Passion',
    description: 'Fajita chicken, onions, peppers, and extra cheese',
    price: 799,
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&q=80&w=800',
    sizes: [
      { label: 'Small', price: 799 },
      { label: 'Medium', price: 1199 },
      { label: 'Large', price: 1499 }
    ]
  },
  {
    id: 's1',
    name: 'Chicken Shawarma',
    description: 'Authentic middle eastern chicken wrap',
    price: 399,
    category: 'shawarma',
    image: 'https://images.unsplash.com/photo-1561651823-34fed022540e?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'f1',
    name: 'Masala Fries',
    description: 'Crispy fries with local spices',
    price: 249,
    category: 'fries',
    image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'd1',
    name: 'Mineral Water',
    description: '500ml pure drinking water',
    price: 50,
    category: 'drink',
    image: 'https://images.unsplash.com/photo-1523362628745-0c100150b504?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'd2',
    name: 'Soft Drink',
    description: 'Regular 250ml chilled drink',
    price: 100,
    category: 'drink',
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'dl1',
    name: 'Family Deal',
    description: '2 Big Burgers, 2 Zinger Burgers, 1 Large Pizza, 1.5L Drink',
    price: 2499,
    category: 'deal',
    image: 'https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?auto=format&fit=crop&q=80&w=800'
  }
];
