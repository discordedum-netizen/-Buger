import { useState } from 'react';
import { products } from '../data';
import { useApp } from '../context';
import { Search } from 'lucide-react';

export const Menu = () => {
  const { addToCart } = useApp();
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = ['all', 'burger', 'pizza', 'shawarma', 'fries', 'drink', 'deal'];

  const filteredProducts = products.filter(p => {
    const matchesCategory = activeCategory === 'all' || p.category === activeCategory;
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h1 className="text-4xl font-black mb-2">Our Delicious Menu</h1>
          <p className="text-gray-500">Choose from our wide variety of flavors</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input 
              type="text" 
              placeholder="Search food..."
              className="pl-10 pr-4 py-2 border-2 border-gray-100 rounded-xl focus:border-orange-600 outline-none w-full sm:w-64"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 no-scrollbar">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-xl font-bold capitalize whitespace-nowrap transition ${
                  activeCategory === cat 
                    ? 'bg-orange-600 text-white' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {filteredProducts.map(item => (
          <div key={item.id} className="bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow border border-gray-50">
            <div className="h-48 overflow-hidden relative">
              <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
              {item.category === 'deal' && (
                <div className="absolute top-3 left-3 bg-red-600 text-white text-xs font-black px-3 py-1 rounded-full">
                  HOT DEAL
                </div>
              )}
            </div>
            <div className="p-5">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-bold text-lg leading-tight">{item.name}</h3>
                <span className="font-black text-orange-600">
                  {item.price} PKR
                </span>
              </div>
              <p className="text-gray-500 text-sm mb-4 line-clamp-2">{item.description}</p>
              
              {item.sizes ? (
                <div className="flex flex-col gap-3">
                  <div className="flex gap-2">
                    {item.sizes.map(size => (
                      <button
                        key={size.label}
                        onClick={() => addToCart(item, size.label)}
                        className="flex-1 border-2 border-orange-100 hover:border-orange-600 text-xs font-bold py-1.5 rounded-lg transition"
                      >
                        {size.label}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <button 
                  onClick={() => addToCart(item)}
                  className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-2.5 rounded-xl transition"
                >
                  Add to Cart
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
      
      {filteredProducts.length === 0 && (
        <div className="text-center py-20">
          <p className="text-gray-400 text-xl font-medium">No items found matching your criteria.</p>
        </div>
      )}
    </div>
  );
};
