import { ArrowRight, Star, Clock, Truck } from 'lucide-react';
import { Link } from 'react-router-dom';
import { products } from '../data';
import { useApp } from '../context';

export const Home = () => {
  const { addToCart } = useApp();
  const featured = products.slice(0, 3);

  return (
    <div className="flex flex-col gap-16 pb-20">
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&q=80&w=1920" 
            className="w-full h-full object-cover brightness-50"
            alt="Hero Burger"
          />
        </div>
        <div className="container mx-auto px-4 relative z-10 text-white">
          <div className="max-w-2xl animate-fade-in-up">
            <h1 className="text-6xl md:text-7xl font-extrabold mb-6 leading-tight">
              Best Burgers in <br />
              <span className="text-yellow-400">Your Town!</span>
            </h1>
            <p className="text-xl mb-8 text-gray-200">
              Experience the authentic taste of juicy patties and premium toppings. 
              Starting from just 399 PKR.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/menu" className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-4 rounded-full font-bold text-lg flex items-center gap-2 transition-transform hover:scale-105">
                Order Now <ArrowRight size={20} />
              </Link>
              <Link to="/menu" className="bg-white/10 backdrop-blur-md border-2 border-white/30 hover:bg-white/20 text-white px-8 py-4 rounded-full font-bold text-lg transition">
                View Menu
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-orange-50 p-8 rounded-3xl flex flex-col items-center text-center">
            <div className="bg-orange-600 p-4 rounded-2xl text-white mb-6">
              <Star size={32} />
            </div>
            <h3 className="text-xl font-bold mb-2">Premium Quality</h3>
            <p className="text-gray-600">We use only the freshest ingredients and 100% halal meat.</p>
          </div>
          <div className="bg-orange-50 p-8 rounded-3xl flex flex-col items-center text-center">
            <div className="bg-orange-600 p-4 rounded-2xl text-white mb-6">
              <Truck size={32} />
            </div>
            <h3 className="text-xl font-bold mb-2">Fast Delivery</h3>
            <p className="text-gray-600">Get your food delivered hot and fresh in under 30 minutes.</p>
          </div>
          <div className="bg-orange-50 p-8 rounded-3xl flex flex-col items-center text-center">
            <div className="bg-orange-600 p-4 rounded-2xl text-white mb-6">
              <Clock size={32} />
            </div>
            <h3 className="text-xl font-bold mb-2">Open 24/7</h3>
            <p className="text-gray-600">Satisfy your burger cravings anytime, day or night.</p>
          </div>
        </div>
      </section>

      {/* Featured Items */}
      <section className="container mx-auto px-4">
        <div className="flex justify-between items-end mb-10">
          <div>
            <h2 className="text-4xl font-extrabold mb-2">Popular Choices</h2>
            <p className="text-gray-500 text-lg">Our most loved burgers and pizzas</p>
          </div>
          <Link to="/menu" className="text-orange-600 font-bold flex items-center gap-1 hover:underline">
            See all <ArrowRight size={18} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {featured.map((item) => (
            <div key={item.id} className="group bg-white rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-300">
              <div className="h-64 overflow-hidden relative">
                <img 
                  src={item.image} 
                  alt={item.name} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute top-4 right-4 bg-yellow-400 text-orange-900 font-bold px-3 py-1 rounded-full text-sm">
                  {item.price} PKR
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold mb-2">{item.name}</h3>
                <p className="text-gray-500 mb-6">{item.description}</p>
                <button 
                  onClick={() => addToCart(item)}
                  className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 rounded-xl transition"
                >
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Special Offer Banner */}
      <section className="container mx-auto px-4">
        <div className="bg-gray-900 rounded-[3rem] p-8 md:p-16 flex flex-col md:flex-row items-center gap-12 text-white relative overflow-hidden">
          <div className="relative z-10 flex-1">
            <span className="bg-orange-600 text-sm font-bold px-4 py-1 rounded-full mb-4 inline-block">LIMITED TIME OFFER</span>
            <h2 className="text-5xl font-black mb-6">Big Savings on Family Deals!</h2>
            <p className="text-gray-400 text-xl mb-8 max-w-lg">
              Get 20% off on all family platters this weekend. Perfect for sharing with friends and family.
            </p>
            <Link to="/menu" className="bg-yellow-400 text-black px-8 py-4 rounded-full font-bold text-lg hover:bg-yellow-300 transition inline-block">
              Claim Offer Now
            </Link>
          </div>
          <div className="flex-1 relative">
            <img 
              src="https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?auto=format&fit=crop&q=80&w=800" 
              className="rounded-2xl shadow-2xl rotate-3"
              alt="Special Deal"
            />
          </div>
        </div>
      </section>
    </div>
  );
};
