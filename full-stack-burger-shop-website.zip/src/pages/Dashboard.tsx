import { useApp } from '../context';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { TrendingUp, Users, ShoppingBag, DollarSign, ArrowUpRight } from 'lucide-react';
import { Navigate } from 'react-router-dom';

const data = [
  { name: 'Mon', income: 45000 },
  { name: 'Tue', income: 52000 },
  { name: 'Wed', income: 48000 },
  { name: 'Thu', income: 61000 },
  { name: 'Fri', income: 85000 },
  { name: 'Sat', income: 98000 },
  { name: 'Sun', income: 92000 },
];

const monthlyData = [
  { name: 'Jan', sales: 1200000 },
  { name: 'Feb', sales: 1500000 },
  { name: 'Mar', sales: 1800000 },
  { name: 'Apr', sales: 1600000 },
  { name: 'May', sales: 2100000 },
  { name: 'Jun', sales: 2450000 },
];

export const Dashboard = () => {
  const { user, orders } = useApp();

  if (!user?.isAdmin) {
    return <Navigate to="/" />;
  }

  const totalIncome = 2450000; // Simulated total
  const dailyIncome = 92000;
  const weeklyIncome = 481000;

  const stats = [
    { label: 'Today\'s Income', value: `${dailyIncome} PKR`, icon: <DollarSign size={24} />, color: 'bg-green-500', trend: '+12%' },
    { label: 'Weekly Income', value: `${weeklyIncome} PKR`, icon: <TrendingUp size={24} />, color: 'bg-blue-500', trend: '+8%' },
    { label: 'Monthly Total', value: `${totalIncome} PKR`, icon: <ShoppingBag size={24} />, color: 'bg-orange-500', trend: '+15%' },
    { label: 'Active Customers', value: '1,284', icon: <Users size={24} />, color: 'bg-purple-500', trend: '+5%' },
  ];

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h1 className="text-4xl font-black mb-2">Admin Dashboard</h1>
          <p className="text-gray-500">Overview of your $ Burger performance</p>
        </div>
        <div className="flex gap-4">
          <button className="bg-orange-600 text-white px-6 py-2 rounded-xl font-bold hover:bg-orange-700 transition">
            Export Report
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
            <div className="flex justify-between items-start mb-4">
              <div className={`${stat.color} p-3 rounded-2xl text-white`}>
                {stat.icon}
              </div>
              <span className="text-green-500 font-bold text-sm flex items-center gap-1">
                {stat.trend} <ArrowUpRight size={16} />
              </span>
            </div>
            <h3 className="text-gray-500 text-sm font-medium mb-1">{stat.label}</h3>
            <p className="text-2xl font-black">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100">
          <h3 className="text-xl font-bold mb-8">Weekly Income Analysis</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  cursor={{ fill: '#fff7ed' }}
                />
                <Bar dataKey="income" fill="#ea580c" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100">
          <h3 className="text-xl font-bold mb-8">Monthly Growth</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Line type="monotone" dataKey="sales" stroke="#ea580c" strokeWidth={4} dot={{ fill: '#ea580c', r: 6 }} activeDot={{ r: 8 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100">
        <h3 className="text-xl font-bold mb-8">Recent Orders</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="text-gray-400 border-b border-gray-100">
                <th className="pb-4 font-medium">Order ID</th>
                <th className="pb-4 font-medium">Customer</th>
                <th className="pb-4 font-medium">Date</th>
                <th className="pb-4 font-medium">Amount</th>
                <th className="pb-4 font-medium">Status</th>
                <th className="pb-4 font-medium">Payment</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {orders.length > 0 ? orders.map((order) => (
                <tr key={order.id} className="group hover:bg-gray-50 transition">
                  <td className="py-4 font-bold">#{order.id}</td>
                  <td className="py-4">User {order.userId}</td>
                  <td className="py-4 text-gray-500">{new Date(order.date).toLocaleDateString()}</td>
                  <td className="py-4 font-bold">{order.total} PKR</td>
                  <td className="py-4">
                    <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold">
                      {order.status}
                    </span>
                  </td>
                  <td className="py-4 text-gray-500">{order.paymentMethod}</td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-gray-400 font-medium">
                    No recent orders to display
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
