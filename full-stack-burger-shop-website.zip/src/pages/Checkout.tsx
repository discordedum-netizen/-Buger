import { useState } from 'react';
import { useApp } from '../context';
import { Trash2, Plus, Minus, CreditCard, ChevronRight, CheckCircle2 } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

export const Cart = () => {
  const { cart, addToCart, removeFromCart } = useApp();
  const subtotal = cart.reduce((acc, item) => acc + (item.selectedPrice * item.quantity), 0);
  const deliveryFee = subtotal > 0 ? 100 : 0;
  const total = subtotal + deliveryFee;

  if (cart.length === 0) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <div className="bg-orange-50 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
          <Trash2 size={40} className="text-orange-600" />
        </div>
        <h2 className="text-3xl font-black mb-4">Your cart is empty</h2>
        <p className="text-gray-500 mb-8 max-w-md mx-auto">Looks like you haven't added anything to your cart yet. Let's find something delicious!</p>
        <Link to="/menu" className="bg-orange-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-orange-700 transition">
          Browse Menu
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-black mb-10">Your Order</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-2 space-y-6">
          {cart.map((item, idx) => (
            <div key={`${item.id}-${item.selectedSize}-${idx}`} className="flex items-center gap-6 bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
              <img src={item.image} alt={item.name} className="w-24 h-24 object-cover rounded-2xl" />
              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-lg">{item.name}</h3>
                    {item.selectedSize && <span className="text-sm text-gray-500">Size: {item.selectedSize}</span>}
                  </div>
                  <span className="font-black">{item.selectedPrice * item.quantity} PKR</span>
                </div>
                <div className="flex items-center gap-4 mt-4">
                  <div className="flex items-center gap-3 bg-gray-100 px-3 py-1 rounded-full">
                    <button onClick={() => removeFromCart(item.id, item.selectedSize)} className="p-1 hover:text-orange-600 transition">
                      <Minus size={16} />
                    </button>
                    <span className="font-bold w-4 text-center">{item.quantity}</span>
                    <button onClick={() => addToCart(item, item.selectedSize)} className="p-1 hover:text-orange-600 transition">
                      <Plus size={16} />
                    </button>
                  </div>
                  <button 
                    onClick={() => {
                      for(let i=0; i<item.quantity; i++) removeFromCart(item.id, item.selectedSize);
                    }}
                    className="text-red-500 hover:text-red-600 text-sm font-bold"
                  >
                    Remove
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="lg:col-1">
          <div className="bg-gray-50 p-8 rounded-[2rem] sticky top-24">
            <h3 className="text-xl font-bold mb-6">Order Summary</h3>
            <div className="space-y-4 mb-8">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span>{subtotal} PKR</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Delivery Fee</span>
                <span>{deliveryFee} PKR</span>
              </div>
              <div className="border-t border-gray-200 pt-4 flex justify-between font-black text-xl">
                <span>Total</span>
                <span className="text-orange-600">{total} PKR</span>
              </div>
            </div>
            <Link to="/checkout" className="w-full bg-orange-600 hover:bg-orange-700 text-white font-black py-4 rounded-2xl transition flex items-center justify-center gap-2 shadow-lg shadow-orange-100">
              Checkout <ChevronRight size={20} />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export const Checkout = () => {
  const { cart, user, addOrder, clearCart } = useApp();
  const navigate = useNavigate();
  const [method, setMethod] = useState<'JazzCash' | 'EasyPaisa' | 'COD'>('JazzCash');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const total = cart.reduce((acc, item) => acc + (item.selectedPrice * item.quantity), 0) + 100;

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      navigate('/login');
      return;
    }
    
    setIsProcessing(true);
    // Simulate payment process
    setTimeout(() => {
      const newOrder = {
        id: Math.random().toString(36).substr(2, 9).toUpperCase(),
        userId: user.id,
        items: [...cart],
        total,
        status: 'completed' as const,
        paymentMethod: method,
        date: new Date().toISOString()
      };
      addOrder(newOrder);
      clearCart();
      setIsProcessing(false);
      setIsSuccess(true);
    }, 2000);
  };

  if (isSuccess) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <div className="bg-green-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 size={48} className="text-green-600" />
        </div>
        <h2 className="text-4xl font-black mb-4 text-gray-900">Order Placed!</h2>
        <p className="text-gray-500 mb-8 max-w-md mx-auto">
          Thank you for your order. Your food is being prepared and will be delivered shortly.
        </p>
        <Link to="/" className="bg-orange-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-orange-700 transition">
          Back to Home
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-black mb-10">Checkout</h1>
        
        <form onSubmit={handlePlaceOrder} className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="space-y-8">
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
              <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                <div className="bg-orange-600 w-2 h-6 rounded-full"></div>
                Delivery Details
              </h3>
              <div className="space-y-4">
                <input type="text" placeholder="Full Name" required className="w-full px-4 py-3 bg-gray-50 border-2 border-transparent focus:border-orange-600 rounded-xl outline-none transition" defaultValue={user?.name} />
                <input type="tel" placeholder="Phone Number (e.g. 03001234567)" required className="w-full px-4 py-3 bg-gray-50 border-2 border-transparent focus:border-orange-600 rounded-xl outline-none transition" />
                <textarea placeholder="Delivery Address" required rows={3} className="w-full px-4 py-3 bg-gray-50 border-2 border-transparent focus:border-orange-600 rounded-xl outline-none transition"></textarea>
              </div>
            </div>

            <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
              <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                <div className="bg-orange-600 w-2 h-6 rounded-full"></div>
                Payment Method
              </h3>
              <div className="grid grid-cols-1 gap-4">
                <button 
                  type="button"
                  onClick={() => setMethod('JazzCash')}
                  className={`flex items-center justify-between p-4 rounded-2xl border-2 transition ${method === 'JazzCash' ? 'border-orange-600 bg-orange-50' : 'border-gray-100 hover:border-orange-200'}`}
                >
                  <span className="font-bold flex items-center gap-3">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/d/df/Jazz_Cash_Logo.png" alt="JazzCash" className="h-6" />
                    JazzCash
                  </span>
                  {method === 'JazzCash' && <CheckCircle2 size={20} className="text-orange-600" />}
                </button>
                <button 
                  type="button"
                  onClick={() => setMethod('EasyPaisa')}
                  className={`flex items-center justify-between p-4 rounded-2xl border-2 transition ${method === 'EasyPaisa' ? 'border-orange-600 bg-orange-50' : 'border-gray-100 hover:border-orange-200'}`}
                >
                  <span className="font-bold flex items-center gap-3">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6A5nSNoW2w7N3S7_N7k0y9H5k_n1_2_N_Gg&s" alt="EasyPaisa" className="h-6 rounded" />
                    EasyPaisa
                  </span>
                  {method === 'EasyPaisa' && <CheckCircle2 size={20} className="text-orange-600" />}
                </button>
                <button 
                  type="button"
                  onClick={() => setMethod('COD')}
                  className={`flex items-center justify-between p-4 rounded-2xl border-2 transition ${method === 'COD' ? 'border-orange-600 bg-orange-50' : 'border-gray-100 hover:border-orange-200'}`}
                >
                  <span className="font-bold flex items-center gap-3">
                    <CreditCard size={20} className="text-gray-600" />
                    Cash on Delivery
                  </span>
                  {method === 'COD' && <CheckCircle2 size={20} className="text-orange-600" />}
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <div className="bg-gray-900 text-white p-8 rounded-[2rem] shadow-xl">
              <h3 className="text-xl font-bold mb-6">Payment Summary</h3>
              <div className="space-y-4 mb-8">
                <div className="flex justify-between text-gray-400">
                  <span>Order Items</span>
                  <span>{cart.length}</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Amount</span>
                  <span>{total - 100} PKR</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Delivery</span>
                  <span>100 PKR</span>
                </div>
                <div className="border-t border-gray-800 pt-4 flex justify-between font-black text-2xl">
                  <span>Total</span>
                  <span className="text-yellow-400">{total} PKR</span>
                </div>
              </div>

              {method !== 'COD' && (
                <div className="mb-8 p-4 bg-gray-800 rounded-2xl border border-gray-700">
                  <p className="text-sm text-gray-400 mb-2">Enter your {method} number</p>
                  <input type="text" placeholder="03XXXXXXXXX" required className="w-full bg-gray-900 border border-gray-700 rounded-xl px-4 py-2 outline-none focus:border-yellow-400 transition" />
                </div>
              )}

              <button 
                type="submit"
                disabled={isProcessing}
                className="w-full bg-yellow-400 hover:bg-yellow-300 text-black font-black py-4 rounded-2xl transition disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isProcessing ? (
                  <>
                    <div className="w-5 h-5 border-3 border-black border-t-transparent rounded-full animate-spin"></div>
                    Processing...
                  </>
                ) : (
                  <>Pay & Place Order</>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
