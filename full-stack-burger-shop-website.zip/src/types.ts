
export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'burger' | 'pizza' | 'shawarma' | 'fries' | 'drink' | 'deal';
  image: string;
  sizes?: {
    label: string;
    price: number;
  }[];
}

export interface CartItem extends Product {
  quantity: number;
  selectedSize?: string;
  selectedPrice: number;
}

export interface User {
  id: string;
  email: string;
  name: string;
  isAdmin: boolean;
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'completed' | 'cancelled';
  paymentMethod: 'JazzCash' | 'EasyPaisa' | 'COD';
  date: string;
}
