import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, User as UserIcon, LogOut } from 'lucide-react';
import { useApp } from '../context';

export const Navbar = () => {
  const { cart, user, setUser } = useApp();
  const navigate = useNavigate();
  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <nav className="bg-orange-600 text-white sticky top-0 z-50 shadow-lg">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <Link to="/" className="flex items-center gap-2 text-2xl font-bold italic">
          <span className="bg-white text-orange-600 rounded-full w-10 h-10 flex items-center justify-center not-italic">$</span>
          Burger
        </Link>

        <div className="hidden md:flex items-center gap-8 font-medium">
          <Link to="/" className="hover:text-orange-200 transition">Home</Link>
          <Link to="/menu" className="hover:text-orange-200 transition">Menu</Link>
          {user?.isAdmin && (
            <Link to="/dashboard" className="hover:text-orange-200 transition text-yellow-300">Admin Dashboard</Link>
          )}
        </div>

        <div className="flex items-center gap-4">
          <Link to="/cart" className="relative p-2 hover:bg-orange-700 rounded-full transition">
            <ShoppingCart size={24} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-yellow-400 text-orange-900 text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </Link>

          {user ? (
            <div className="flex items-center gap-4">
              <span className="hidden sm:inline">Hi, {user.name}</span>
              <button 
                onClick={() => { setUser(null); navigate('/'); }}
                className="p-2 hover:bg-orange-700 rounded-full transition"
                title="Logout"
              >
                <LogOut size={24} />
              </button>
            </div>
          ) : (
            <Link to="/login" className="flex items-center gap-2 bg-white text-orange-600 px-4 py-1.5 rounded-full font-bold hover:bg-orange-50 transition">
              <UserIcon size={20} />
              Login
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};
